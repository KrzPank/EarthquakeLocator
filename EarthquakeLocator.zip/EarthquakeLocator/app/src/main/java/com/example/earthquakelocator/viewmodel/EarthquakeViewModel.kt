package com.example.earthquakelocator.viewmodel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.earthquakelocator.network.RetrofitClient
import kotlinx.coroutines.launch
import android.util.Log
import com.example.earthquakelocator.model.EarthquakeResponse
import kotlinx.coroutines.flow.MutableStateFlow

open class EarthquakeViewModel : ViewModel() {

    private val _earthquakes = MutableStateFlow<EarthquakeResponse?>(null)

    open fun fetchEarthquakes(
        startDate: String,
        endDate: String,
        minMagnitude: Double,
        latitude: Double,
        longitude: Double,
        radius: Double
    ) {
        viewModelScope.launch {
            try {
                val response = RetrofitClient.api.getEarthquakes(
                    start = startDate,
                    end = endDate,
                    minMag = minMagnitude,
                    lat = latitude,
                    lon = longitude,
                    radius = radius
                )

                _earthquakes.value = response

                response.features.forEach { feature ->
                    val mag = feature.properties.mag
                    val place = feature.properties.place
                    val time = feature.properties.time
                    val coords = feature.geometry.coordinates

                    Log.d("EQuake", "Mag: $mag | Place: $place | Time: $time | Coords: $coords")
                }

            } catch (e: Exception) {
                Log.e("EQuake", "Błąd pobierania: ${e.message}")
            }
        }
    }
}
