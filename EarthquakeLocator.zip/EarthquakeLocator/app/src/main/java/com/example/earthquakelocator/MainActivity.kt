package com.example.earthquakelocator

import android.content.Intent
import android.location.Geocoder
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.earthquakelocator.util.GeoJsonLinkGenerator
import com.example.earthquakelocator.viewmodel.EarthquakeViewModel
import androidx.compose.ui.platform.LocalContext
import com.example.earthquakelocator.network.RetrofitClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Column(modifier = Modifier.padding(16.dp)) {
                    EarthquakeForm()
                }
            }
        }
    }
}

@Composable
fun EarthquakeForm() {
    var location by remember { mutableStateOf("") }
    var startDate by remember { mutableStateOf("") }
    var endDate by remember { mutableStateOf("") }
    var minMag by remember { mutableStateOf("") }
    var radius by remember { mutableStateOf("") }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(
            value = location,
            onValueChange = { location = it },
            label = { Text("Lokalizacja (np. Warsaw)") }
        )

        OutlinedTextField(
            value = startDate,
            onValueChange = { startDate = it },
            label = { Text("Data początkowa (YYYY-MM-DD)") }
        )

        OutlinedTextField(
            value = endDate,
            onValueChange = { endDate = it },
            label = { Text("Data końcowa (YYYY-MM-DD)") }
        )

        OutlinedTextField(
            value = minMag,
            onValueChange = { minMag = it },
            label = { Text("Minimalna magnituda (np. 3.5)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )

        OutlinedTextField(
            value = radius,
            onValueChange = {radius = it},
            label = {Text("Minimalna odległość geograficzna")},
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )

        val context = LocalContext.current

        Button(onClick = {
            val mag = minMag.toDoubleOrNull() ?: 1.0
            val rad = radius.toDoubleOrNull() ?: 1000.0

            if (location.isNotBlank() && startDate.isNotBlank() && endDate.isNotBlank()) {
                val geocoder = Geocoder(context)
                val addresses = geocoder.getFromLocationName(location, 1)

                if (!addresses.isNullOrEmpty()) {
                    val lat = addresses[0].latitude
                    val lon = addresses[0].longitude

                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            val response = RetrofitClient.api.getEarthquakes(
                                start = startDate,
                                end = endDate,
                                minMag = mag,
                                lat = lat,
                                lon = lon,
                                radius = rad
                            )

                            withContext(Dispatchers.Main) {
                                val url = GeoJsonLinkGenerator.generateLink(response)
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                context.startActivity(intent)
                            }
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                Toast.makeText(context, "Błąd: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                } else {
                    Toast.makeText(context, "Nie znaleziono lokalizacji", Toast.LENGTH_SHORT).show()
                }
            }
        }) {
            Text("Pobierz i pokaż")
        }

    }
}

/*
@Preview(showBackground = true)
@Composable
fun EarthquakeFormPreview() {
    val dummyViewModel = object : EarthquakeViewModel() {
        override fun fetchEarthquakes(
            startDate: String,
            endDate: String,
            minMag: Double,
            lat: Double,
            lon: Double,
            radius: Double
        ) {
            //nothing
        }
    }
    EarthquakeForm(viewModel = dummyViewModel)
}
*/
